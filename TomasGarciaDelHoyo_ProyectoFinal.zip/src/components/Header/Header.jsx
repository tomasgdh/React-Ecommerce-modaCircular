
import "./Header.css"

const HomePage = () => {
    return (
      <div className="header">
        <h1>María Circle Fashion</h1>
      </div>
    );
  };
  export default HomePage;