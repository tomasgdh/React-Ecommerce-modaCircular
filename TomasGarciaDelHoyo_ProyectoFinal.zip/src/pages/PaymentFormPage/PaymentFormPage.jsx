// Components
import PaymentForm from "../../components/PaymentForm/PaymentForm";

const PaymentFormPage = () => {
  return (
    <div >
      <PaymentForm />
    </div>
  );
};

export default PaymentFormPage;