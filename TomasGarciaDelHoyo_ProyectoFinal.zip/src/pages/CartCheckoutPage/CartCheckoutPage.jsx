// Own Components
import CartCheckOut from "../../components/CartCheckOut/CartCheckOut";

const CartCheckOutPage = () => {
  return (
    <>
      <CartCheckOut />
    </>
  );
};

export default CartCheckOutPage;