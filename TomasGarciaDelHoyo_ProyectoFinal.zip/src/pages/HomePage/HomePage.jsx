// Own Components
import CardListContainer from "../../components/CardListContainer/CardListContainer";

const HomePage = () => {
  return (
    <div >
      <CardListContainer />
    </div>
  );
};

export default HomePage;
